#ifndef myStepMotor_h
#define myStepMotor_h
#include "Arduino.h"

class myStepMotor
{
	public:
		Motor(int NbStep,int List[4], int pin1, int pin2, int pin3, int pin4);
		void Step(bool direction);
		void SetDelay(int delay);
	private:
		int _NbStep;
		int _List[4]; 
		int _pin1; 
		int _pin2; 
		int _pin3; 
		int _pin4;
		int _delay;
		int _pos;


};

#endif
