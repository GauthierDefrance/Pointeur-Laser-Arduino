#include "Arduino.h"
#include "myStepMotor.h"




// Pin 1,2,3,4 sont là pour indiquer quelles sont les ports de connexion vers la puce ULN.
//La liste sert à initialiser l'état des électro-aimants.
//Veuillez écrire dans ce paramètre [1,0,0,0] 
Motor::Motor(int NbStep,int List[4], int pin1, int pin2, int pin3, int pin4)
{
	_NbStep=NbStep;
	_List[0]=List[0];
	_List[1]=List[1];
	_List[2]=List[2];
	_List[3]=List[3];
	_pin1=pin1 ; 
	_pin2=pin2 ; 
	_pin3=pin3 ; 
	_pin4=pin4 ;
	_pos=0;
	pinMode(_pin1,OUTPUT);
	pinMode(_pin2,OUTPUT);
	pinMode(_pin3,OUTPUT);
	pinMode(_pin4,OUTPUT);

}

//Ici se trouve la fonction Step prenant comme paramètre un booléen.
//A chaque fois que vous l'appelerez elle fera un demi pas dans une direction ou une autre.
void myStepMotor::Step(bool direction)
{
_pos=_pos%4
if(direction){
if(_List[(v-1)%4]==1) _List[v%4]=0;
else
	{
	_List[(v+1)%4]=1;
	_pos=(_pos+1)%4;
	}		
}
else{
if(_List[(v-1)%4]==0) _List[(v-1)%4]=1;
else
	{
	_List[(v)]=0;
	_pos=(_pos-1)%4;
	}		
}
digitalWrite(_pin1,_List[0]);
digitalWrite(_pin2,_List[1]);
digitalWrite(_pin3,_List[2]);
digitalWrite(_pin4,_List[3]);

}



//Cette fonction sert à associer un delay pour chaque moteur pas à pas.
void myStepMotor::SetDelay(int delay)
{
_delay = delay;
}